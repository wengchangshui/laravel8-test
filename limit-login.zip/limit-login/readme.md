### 介绍

> - 本项目用来对登录时间进行限制。
> - 产品中使用的是oauth2的个人令牌，永久有效，登录后不需要进行刷新token。

### 使用说明

> 清除缓存 更新后使用 清除所有用户登录缓存信息 需要重新登录 (api方式只能 staff服务使用)
> ``` bash
> php artisan login:cache:flush
> ```

### 发布配置
 
> ```bash
> php artisan vendor:publish --provider="ShallBuy\LimitLogin\LimitLoginProvider" 
> ```

### 配置信息

> ```php 
> // config/limit_login.php
> [
>   'should_route_names' => ['xx'], // 需要验证的登录是否过期的路由名称
>   'except_route_names' => ['xx'], // 排除验证的登录是否过期的路由名称
> ] 
> ```

### 其他说明

> 1. 登录一次最长10小时持续在线   
> 2. 30分钟没有操作则退出登录
 
### 响应说明

> ```json
> {
>    "message": "token 已过期, 请重新登录",
>    "data": [],
>    "code": 190021,
>    "prompt": 0,
>    "url_type": "",
>    "url": ""
> }
> ```

> ```json
> {
>    "message": "token 解析错误",
>    "data": [],
>    "code": 190020,
>    "prompt": 0,
>    "url_type": "",
>    "url": ""
> }
> ```