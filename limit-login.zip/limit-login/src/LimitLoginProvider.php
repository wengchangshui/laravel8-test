<?php

namespace ShallBuy\LimitLogin;

use Illuminate\Cache\RedisStore;
use Illuminate\Redis\RedisManager;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\ServiceProvider;
use Laravel\Passport\Events\AccessTokenCreated;
use ShallBuy\LimitLogin\Cache\LimitCache;
use ShallBuy\LimitLogin\Cache\LimitRedisStore;
use ShallBuy\LimitLogin\Middlewares\CheckLimitMiddleware;
use ShallBuy\LimitLogin\Services\LimitLoginService;

class LimitLoginProvider extends ServiceProvider
{
    public $singletons = [
        LimitCache::class => LimitCache::class
    ];

    public function register()
    {
        parent::register();
    }

    public function boot()
    {
        $this->publishes([
            __DIR__ . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'limit_login.php' => config_path('limit_login.php')
        ]);

        if ($this->app->runningInConsole()) {
            $this->commands([
                \ShallBuy\LimitLogin\Commands\LoginCacheFlush::class,
            ]);
        }

        //添加缓存驱动
        $this->registerCacheDriver();
        //添加中间件
        $this->registerMiddleware();
        //注册监听器
        $this->registerListener();
    }

    /**
     * 添加limit_cache 缓存驱动
     */
    protected function registerCacheDriver()
    {
        $redis_driver = env('REDIS_CLIENT', 'predis');

        $redis_config = [
            'client'  => $redis_driver,
            'options' => [
                'cluster' => 'redis'
            ],
            'default' => [
                'url'      => env('REDIS_URL'),
                'host'     => env('REDIS_HOST', '127.0.0.1'),
                'password' => env('REDIS_PASSWORD', null),
                'port'     => env('REDIS_PORT', '6379'),
                'database' => env('REDIS_DB', '0'),
            ]
        ];

        $redis = (new RedisManager($this->app, $redis_driver, $redis_config));

        Cache::extend('limit_cache', function ($app) use ($redis) {
            return Cache::repository(new LimitRedisStore($redis, 'limit_cache', 'default'));
        });

        config(['cache.stores.limit_cache' => ['driver' => 'limit_cache', 'connection' => 'default']]);
    }

    /**
     * 在路由中添加中间件
     */
    protected function registerMiddleware()
    {
        /**
         * @var Router $router
         */
        $router = $this->app['router'];

        $router->pushMiddlewareToGroup('api', CheckLimitMiddleware::class);
        $router->pushMiddlewareToGroup('web', CheckLimitMiddleware::class);

        $router->middleware([CheckLimitMiddleware::class]);
    }

    /**
     * 注册事件
     */
    protected function registerListener()
    {
        //生成access_token后 录入缓存
        $this->app['events']->listen('Laravel\Passport\Events\AccessTokenCreated', function ($event) {
            /**
             * @var AccessTokenCreated $event
             */
            (new LimitLoginService('', $event->tokenId))->setCache();
        });
    }
}
