<?php

namespace ShallBuy\LimitLogin\Cache;

use Illuminate\Support\Facades\Facade;

class LimitCacheFacade extends Facade
{
    protected static function getFacadeAccessor()
    {
        return LimitCache::class;
    }
}
