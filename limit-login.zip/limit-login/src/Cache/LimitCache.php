<?php

namespace ShallBuy\LimitLogin\Cache;

use Illuminate\Cache\Repository;

/**
 * Class LimitCache
 * @package ShallBuy\LimitLogin\Cache
 * @property \Cache $Cache
 */
class LimitCache
{
    protected $Cache;

    public function __construct()
    {
        $this->Cache = \Cache::store('limit_cache');
    }

    public function __call($method, $params)
    {
        if (method_exists($this->Cache, $method)) {
            return $this->Cache->$method(...$params);
        };
    }
}
