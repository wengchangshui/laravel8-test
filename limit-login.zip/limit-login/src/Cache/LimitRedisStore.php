<?php

namespace ShallBuy\LimitLogin\Cache;

use Illuminate\Cache\RedisStore;

class LimitRedisStore extends RedisStore
{

}
