<?php

return [
    'life_minutes'    => 60 * 8, //token最长有效时间 单位分钟
    'cooling_minutes' => 30, //多长时间无操作退出登录 单位分钟
    'cache_tag_name'  => 'staff-login-limit-remaining-times',
    'except_routes'   => [], //不需要验证的路由名称
    'should_routes'   => [] //需要验证的路由名称
];