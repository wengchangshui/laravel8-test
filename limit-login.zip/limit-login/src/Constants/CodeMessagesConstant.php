<?php

namespace ShallBuy\LimitLogin\Constants;

class CodeMessagesConstant
{
    const LIMIT_LOGIN_PARSE_ERROR = ['code' => 190020, 'message' => 'token 解析错误'];
    const LIMIT_LOGIN_EXPIRED = ['code' => 190021, 'message' => 'token 已过期, 请重新登录'];
}