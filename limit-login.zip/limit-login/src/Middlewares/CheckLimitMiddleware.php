<?php

namespace ShallBuy\LimitLogin\Middlewares;

use Illuminate\Http\Request;
use ShallBuy\LimitLogin\Services\LimitLoginService;
use function Composer\Autoload\includeFile;

class CheckLimitMiddleware
{
    public function handle(Request $request, \Closure $next)
    {
        $uri = $request->route()->uri();
        $route_name = $request->route()->getName() ?? '';

        $uri_arr = explode('/', $uri);

        $should_routes = config('limit_login.should_routes', []);
        $except_routes = config('limit_login.except_routes', []);

        //staff模块接口
        if (($uri_arr[1] ?? '') === 'staff') {
            //排除路由
            if (!in_array($route_name, $except_routes)) {
                (new LimitLoginService())->checkOrRefreshTime();
            }
        } else {
            //验证路由
            if (in_array($route_name, $should_routes)) {
                (new LimitLoginService())->checkOrRefreshTime();
            }
        }

        return $next($request);
    }
}
