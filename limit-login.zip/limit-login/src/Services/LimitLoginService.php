<?php

namespace ShallBuy\LimitLogin\Services;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Lcobucci\JWT\Parser;
use ShallBuy\LimitLogin\Constants\CodeMessagesConstant;
use Illuminate\Http\Exceptions\HttpResponseException;

/**
 * Class RefreshTokenService
 * @package Staff\Services
 * @property $TagName
 * @property $LifeMinutes
 * @property $CoolingMinutes
 * @property $Key;
 */
class LimitLoginService
{
    public $TagName;
    public $LifeMinutes;
    public $CoolingMinutes;
    public $Key;

    public function __construct($token = '', $key = '')
    {
        $this->TagName = config('limit_login.cache_tag_name', 'staff-login-limit-remaining-times');
        $this->LifeMinutes = config('limit_login.life_minutes', 60 * 12);
        $this->CoolingMinutes = config('limit_login.cooling_minutes', 30);
        $this->Key = $this->getKey($token, $key);
    }

    /**
     * 获取redis缓存key
     * @param string $token
     * @return mixed
     */
    public function getKey($token = '', $key = '')
    {
        if (!app()->runningInConsole()) {
            try {
                if ($key) {
                    return $key;
                } else {
                    if ($token === '') {
                        $bearer_token = request()->header('Authorization');
                        $token = Str::after($bearer_token, 'Bearer ');
                    }

                    $parse_token = (new Parser())->parse($token);
                    //唯一token标识
                    return $parse_token->getHeader('jti');
                }
            } catch (\Exception $exception) {
                throw new HttpResponseException(response(CodeMessagesConstant::LIMIT_LOGIN_PARSE_ERROR, 401));
            }
        }
    }

    /**
     * 验证和更新登录情况
     * @throws HttpResponseException
     */
    public function checkOrRefreshTime()
    {
        try {
            //已过期 -> 重新登录
            if (!$cache_info = $this->getCache()) {
                throw new HttpResponseException(response(CodeMessagesConstant::LIMIT_LOGIN_EXPIRED, 401));
            }
            //超过时限没有进行操作
            if (time() > ($cache_info['operate_time'] + 60 * $this->CoolingMinutes)) {
                $this->clearCache();
                throw new HttpResponseException(response(CodeMessagesConstant::LIMIT_LOGIN_EXPIRED, 401));
            } else {
                //$this->setCache();
                $this->updateCache();
            }
        } catch (HttpResponseException $exception) {
            throw $exception;
        } catch (\Exception $exception) {
            throw new HttpResponseException(response(CodeMessagesConstant::LIMIT_LOGIN_PARSE_ERROR, 401));
        }
    }

    /**
     * 获取缓存信息
     * @return array|mixed
     */
    public function getCache()
    {
        return \LimitCache::tags($this->TagName)->get($this->Key);
    }

    /**
     * 设置缓存信息
     */
    public function setCache()
    {
        $ep_time = now()->addMinutes($this->LifeMinutes);

        \LimitCache::tags($this->TagName)
            ->put(
                $this->Key,
                ['operate_time' => time(), 'ep_time' => $ep_time],
                now()->addMinutes($this->LifeMinutes)
            );
    }

    /**
     * 更新缓存信息
     */
    public function updateCache()
    {
        $ep_time = $this->getCache()['ep_time'] ?? now();

        \LimitCache::tags($this->TagName)
            ->put(
                $this->Key,
                ['operate_time' => time(), 'ep_time' => $ep_time],
                $ep_time
            );
    }

    /**
     * 清除缓存信息
     */
    public function clearCache()
    {
        \LimitCache::tags($this->TagName)->forget($this->Key);
    }

    /**
     * 清除所有缓存
     */
    public function clearAllCache()
    {
        \LimitCache::tags($this->TagName)->flush();
    }
}
